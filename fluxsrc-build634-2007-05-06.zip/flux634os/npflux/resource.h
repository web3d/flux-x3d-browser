//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by npflux.rc
//
#define IDC_CONSOLETEXT                 212
#define IDD_CONSOLE                     228
#define IDB_DASHBOARD                   239
#define IDB_EXPLORE                     240
#define IDB_EXAMINE                     241
#define IDB_SEEK                        242
#define IDB_LEVEL                       243
#define IDB_BACK                        244
#define IDB_FORWARD                     245
#define IDB_VIEWNEXT                    246
#define IDB_VIEWPREVIOUS                247
#define IDB_HELP                        248
#define IDB_INFO                        249
#define IDB_PREFERENCES                 250
#define IDB_VIEWNAMES                   253

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        7000
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         7000
#define _APS_NEXT_SYMED_VALUE           7002
#endif
#endif
