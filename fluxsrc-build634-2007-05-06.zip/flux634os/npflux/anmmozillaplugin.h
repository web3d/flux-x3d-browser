#if !defined(AFX_ANMMOZILLAPLUGIN_H__AD1607A5_FD5F_4DAB_8CEE_358FA3A30A66__INCLUDED_)
#define AFX_ANMMOZILLAPLUGIN_H__AD1607A5_FD5F_4DAB_8CEE_358FA3A30A66__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// anmmozillaplugin.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAnmMozillaPlugin window

class CAnmMozillaPlugin : public CWnd
{
// Construction
public:
	CAnmMozillaPlugin();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnmMozillaPlugin)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAnmMozillaPlugin();

	// Generated message map functions
protected:
	//{{AFX_MSG(CAnmMozillaPlugin)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANMMOZILLAPLUGIN_H__AD1607A5_FD5F_4DAB_8CEE_358FA3A30A66__INCLUDED_)
